<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ko" xml:lang="ko">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=EDGE" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="keywords" content=""/>
<meta name="description" content="보도자료">
<meta property="og:type" content="website">
<meta property="og:title" content="NEWS - REGISTER - 윈덤 강원 고성">
<meta property="og:description" content="보도자료">
<meta property="og:image" content="http://wyndham-gwgs.co.kr/images/common/ogimage.gif">
<meta property="og:url" content="http://wyndham-gwgs.co.kr">

<!--<link rel="stylesheet" type="text/css" href="/common/css/common.css?v=20211231071956"/>-->
<link rel="stylesheet" type="text/css" href="/common/css/font.css"/>
<link rel="stylesheet" type="text/css" href="/common/css/base.css?v=20211231071956"/>
<link rel="stylesheet" type="text/css" href="/common/css/layout.css?v=20211231071956"/>
<link rel="stylesheet" type="text/css" href="/common/css/content.css?v=20211231071956"/>
<link rel="stylesheet" type="text/css" href="/common/css/board.css?v=20211231071956"/>
<script type="text/javascript" src="/common/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/common/js/common.js?v=20211231071956"></script>
<script type="text/javascript" src="/common/js/script_top.js?v=1"></script>
<meta name="naver-site-verification" content="28291699597803fe9e8d8edf40ea1bf286da22dd" /><title>NEWS - REGISTER - 윈덤 강원 고성</title>
<script type="text/javascript">
$(document).ready(function (){
	
});	
</script>
</head>
	<body>
	<div id="spNavi">
	<h3>메뉴바로가기</h3>
    <a href="#content">본문 내용으로 바로가기</a> 
    <a href="#left">메뉴으로 바로가기</a> 
	</div>

		
	<div id="header">
    	
    	<div id="menu-Area" class='sub'>
        	<div class="gnbbox1">
            			</div>
        	<div id="menu-box">
            	<div class="bgdepth1">                
                    <a href="/"><img src="/images/common/logo1.png" alt="" class="logo1 chg1" /></a>
                        
                    <div class="mmnbtn1">
                        <div class="btn trigger"><span class="line"></span></div>
                    </div>
                    <div class="topmenu">                                        	                        
                        <ul class="menudep1">  
                        	<li class="mmenu0"><a href="/" class="mnlnk1">HOME</a></li>
                                                        <li class="mmenu0"><a href="/wyndham/wyndham.php" class="mnlnk1 ">WYNDHAM</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/wyndham/wyndham.php">WYNDHAM</a></li> 
                                                                	<li><a href="/wyndham/brand.php">BRAND</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/info/overview.php" class="mnlnk1 ">SUMMARY</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/info/overview.php">OVERVIEW</a></li> 
                                                                	<li><a href="/direction/direction.php">DIRECTIONS</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/premium/premium.php" class="mnlnk1 ">PREMIUM</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/premium/premium.php">PREMIUM</a></li> 
                                                                	<li><a href="/location/location.php">LOCATION</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/unit/plan.php" class="mnlnk1 ">UNIT</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/unit/plan.php">PLAN</a></li> 
                                                                	<li><a href="/unit/special.php">SPECIAL</a></li> 
                                                                	<li><a href="/unit/community.php">COMMUNITY</a></li> 
                                                                	<li><a href="/unit/type.php">TYPE</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/register/client.php" class="mnlnk1 on ">REGISTER</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/register/client.php">REGISTER</a></li> 
                                                                	<li><a href="/reserve/visit.php" onclick="return _alert('준비중입니다.');">RESERVATION</a></li> 
                                                                	<li><a href="/register/media.php">MEDIA</a></li> 
                                                                	<li><a href="/register/news.php">NEWS</a></li> 
                                                                </ul>
                                                            </li>    
                                                 
                        </ul>                                                                     
                    </div>       
                    <div class="mnbnn1">
                        <img src="/images/common/top_tel1.png" alt="" class="chg1" />
                        <a href="/register/client.php" class="mL20"><img src="/images/common/btn_client1.png" alt="" /></a>
                    </div>             
                </div>                
			</div>                                               
        </div>   
    </div>
    
    <div class="svisualbox1">            	
    <div class="slider1">
         <!-- Jssor Slider Begin -->
        <!-- You can move inline styles to css file or css block. --> 
        <div id="slider1_container" class="slider_sub1">
            
            <!-- Loading Screen --> 
            <div u="loading" style="position: absolute; top: 0px; left: 0px;">
                <div style="filter: alpha(opacity=20); opacity:0.2; position: absolute; display: block; background-color: #e4e4e4; top: 0px; left: 0px;width: 100%; height:100%;"> </div> 
                <div style="position: absolute; display: block; background: url(/images/common/ico/ajax-loader.gif) no-repeat center center; top: 0px; left: 0px;width: 100%;height:100%;"> </div> 
            </div> 
            
            <!-- Slides Container --> 
            <div u="slides" class="slider_box1">                        	                        	                            
                <div>
                    <!--<img u="image" src="/images/sub/visual1_211019.jpg" />-->
					<img u="image" src="/images/sub/visual1_211026.jpg?v=1" />
                    <div u="caption" style="position: absolute; left:0; top:316px; width:100%; height:200px; text-align:center;">
                    	<div class="subtitbox1">                        	
                            <h2>보도자료</h2>
                            <em class="tit1">NEWS</em>
                            						</div>
					</div>
                </div>                  	
            </div> 
            
            <!-- Bullet Navigator Skin Begin -->
            <!-- bullet navigator container -->
            <div u="navigator" class="jssorb03" style="position: absolute; bottom: 16px; left: 6px;">
            <!-- bullet navigator item prototype -->
                <div u="prototype" style="POSITION: absolute; WIDTH: 21px; HEIGHT: 21px; text-align:center; line-height:21px; color:White; font-size:12px;"><div u="numbertemplate"></div></div>
            </div>
            <!-- Bullet Navigator Skin End -->
            
            <!-- Arrow Navigator Skin Begin -->
            <!-- Arrow Left -->
            <span u="arrowleft" class="jssora20l"></span>
            <!-- Arrow Right -->
            <span u="arrowright" class="jssora20r"></span>
            <!-- Arrow Navigator Skin End -->
        </div> 
        <!-- Jssor Slider End -->
    </div>
</div>
<script type="text/javascript" src="/common/js/SplitText.js"></script>
<script type="text/javascript" src="/common/js/TweenMax.min.js"></script>
<script type="text/javascript">
$(document).ready(function(e) {
 	$ele = $(".svisualbox1");
	//$bg = $ele.find(".slider1");
	$title1 = $ele.find(".tit1");   
	$title2 = $ele.find("h2"); 
	$title3 = $ele.find("p");
	$menu = $ele.find(".submn1>li"); 
	
	var mySplitText = new SplitText($title2, { type: "chars"});
	//var word_tl = new TimelineLite({delay:1});
	var shuffleCharArray = shuffleArray(mySplitText.chars);           
	       

	TweenLite.set(shuffleCharArray, {autoAlpha:0}); 

	tl = new TimelineLite({paused:true, onComplete:function(){  }});           	
	tl.staggerTo(shuffleCharArray, .8, {autoAlpha: 1, ease:Cubic.easeOut}, 0.01)   
	tl.staggerFrom($menu,.4, {autoAlpha: 0, y:20, ease:Cubic.easeOut}, 0.04)	
	//tl.from($bg, 2, {autoAlpha:0, scale:1.12, skewX:0.001, ease:Power2.easeOut}, "-=2.9")             
	tl.from($title1, .7, {autoAlpha:0, y:-20, ease:Power2.easeOut}, "-=.8")
	tl.from($title3, .7, {autoAlpha:0, y:-20, ease:Power2.easeOut}, "-=.8")
	//tl.to($ele, 1.2, {height:740, ease:Power2.easeOut}, "-=1.2")
	tl.play();
	//tl.timeScale(1.5);

	function shuffleArray(array) {
		for (var i = array.length - 1; i > 0; i--) {
			var j = Math.floor(Math.random() * (i + 1));
			var temp = array[i];
			array[i] = array[j];
			array[j] = temp;
		}
		return array;
	}
});
</script>

<link rel="stylesheet" type="text/css" href="/common/css/jssor/jssor.css"/>
<script type="text/javascript" src="/common/js/jssor/jssor.js"></script>
<script type="text/javascript" src="/common/js/jssor/jssor.slider.js"></script>
<script type="text/javascript" src="/common/js/jssor/scripts2.js"></script>	    <div id="wrap">
        <div id="swrap">   		

            <div id="scontent">
                <div id="content">
                   
                    
                    
<script type="text/javascript">
<!--
function check_all() {
	Obj = document.getElementsByName("idxChk[]");
	totalCnt = Obj.length;
	if(totalCnt == 0) {
		alert("체크하실 목록이 없습니다.");
	}
	else if(Obj[0].checked == true) {
		for(i = 0; i < totalCnt; i++) {
			Obj[i].checked = false;
		}
	}
	else {
		for(i = 0; i < totalCnt; i++) {
			Obj[i].checked = true;
		}
	}
}

function delete_check() {
	Obj = document.getElementsByName("idxChk[]");
	cnt = Obj.length;
	idxArr = "";
	if(cnt == undefined || cnt == 0) {
		alert("삭제하실 목록이 없습니다.");
		return;
	}	// if(cnt == undefined)

	for(i = 0; i < cnt; i++) {
		if(Obj[i].checked == true) {
			idxArr += "," + Obj[i].value;
		}
	}	// for(i = 1; i < cnt; i++)
	idx = idxArr.substr(1);
	delete_list(idx);
}

function delete_list(Idx) {
	if(Idx == "") {
		alert("삭제하실 목록을 체크해주세요.");
		return;
	}
	if(confirm("삭제하시겠습니까?")) {
		location.href = "/board/delete.php?page=1&board_id=press&search_type=&search_word=&idx=" + Idx;
	}	// if(confirm("삭제하시겠습니까?"))
}

function search_board() {
    var search_type,search_word,category;
   
    /*var search_type =document.getElementById("search_type").value;
	var search_word =document.getElementById("search_word").value;
    var category = document.getElementById("category").value;
    */
	chksales = "";
    if($("#chksales").length > 0){
         if (document.getElementById('chksales') != null) {
        chksales = document.getElementById("chksales").value;
        }
    }
	
    category = "";
    if($("#category").length > 0){
         if (document.getElementById('category') != null) {
        category = document.getElementById("category").value;
        }
    }


    if (document.getElementById('search_type') != null) {
    search_type = document.getElementById("search_type").value;
    }
    if (document.getElementById('search_word') != null) {
    search_word = document.getElementById("search_word").value;
    }
/*
    if(!search_word) {
    alert("검색어를 입력해주세요.");
    document.getElementById("search_word").focus();
    return;
    }	// if(!objForm.search_word.value)
  */ 
	location.href = "?search_type=" + search_type + "&search_word="+search_word+"&category="+category+"&chksales="+chksales+"&board_id=press";
}

function _onMove(){
	Obj = document.getElementsByName("idxChk[]");
	cnt = Obj.length;
	idxArr = "";
	if(cnt == undefined || cnt == 0) {
		alert("선택된 목록이 없습니다.");
		return;
	}	// if(cnt == undefined)

	for(i = 0; i < cnt; i++) {
		if(Obj[i].checked == true) {
			idxArr += "," + Obj[i].value;
		}
	}	// for(i = 1; i < cnt; i++)
	idx = idxArr.substr(1);
	//console.log(idx);
	if (idx == ""){
		alert("선택된 목록이 없습니다.");
		return;
	}
	var url="/board/board_move.php";  
	var params="idx="+idx;
	divFilter($(document.body), "dobox3", "A", 850);
	$("#dobox2").load(url,{"idx":idx,"pmode":"WIN"}, function(responseTxt, statusTxt, xhr){
	});
}
//-->
</script>
<!-- 리스트 시작 -->
	<input type="hidden" id="idxChk" />
	<!-- 검색 시작 -->
<!-- 검색 끝 -->

<table width="100%" class="tbl_type1">
	<colgroup>
    	<col width="8%" />
                <col width="" />
		        <col width="100" />
            </colgroup>
	<tr>
		<th>번호</th>
				<th>제목</th>
        		<th>등록일</th>
        	</tr>
		<tr>
		<td>
			35		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=39&board_id=press&amp;page=1&amp;">[경상일보] 전세대 오션뷰 생활숙박시설 ‘윈덤 강원 고성’ 분양 중</a>-->
			<a href="http://www.ksilbo.co.kr/news/articleView.html?idxno=921300" target="_blank">[경상일보] 전세대 오션뷰 생활숙박시설 ‘윈덤 강원 고성’ 분양 중</a>
			            		</td>
        		<td>2021-12-14</td>
        	</tr>
			<tr>
		<td>
			34		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=38&board_id=press&amp;page=1&amp;">[더드라이브] 생활숙박시설 ‘윈덤 강원 고성’ 분양 중</a>-->
			<a href="http://www.thedrive.co.kr/news/newsview.php?ncode=1065576533709353" target="_blank">[더드라이브] 생활숙박시설 ‘윈덤 강원 고성’ 분양 중</a>
			            		</td>
        		<td>2021-12-13</td>
        	</tr>
			<tr>
		<td>
			33		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=37&board_id=press&amp;page=1&amp;">[부산제일경제] 오너십 프리미엄, 오션과 마운틴 더블뷰 ‘윈덤 강원 고성’</a>-->
			<a href="http://www.busaneconomy.com/news/articleView.html?idxno=266827" target="_blank">[부산제일경제] 오너십 프리미엄, 오션과 마운틴 더블뷰 ‘윈덤 강원 고성’</a>
			            		</td>
        		<td>2021-12-10</td>
        	</tr>
			<tr>
		<td>
			32		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=36&board_id=press&amp;page=1&amp;">[글로벌경제신문] 신세계건설 시공, ‘윈덤 강원 고성’ 공급</a>-->
			<a href="http://www.getnews.co.kr/news/articleView.html?idxno=563384" target="_blank">[글로벌경제신문] 신세계건설 시공, ‘윈덤 강원 고성’ 공급</a>
			            		</td>
        		<td>2021-12-08</td>
        	</tr>
			<tr>
		<td>
			31		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=35&board_id=press&amp;page=1&amp;">[제주교통복지신문] ‘윈덤 강원 고성’, 12월 1일 모델하우스 오픈 후 본격 분양</a>-->
			<a href="http://www.jejutwn.com/news/article.html?no=112725" target="_blank">[제주교통복지신문] ‘윈덤 강원 고성’, 12월 1일 모델하우스 오픈 후 본격 분양</a>
			            		</td>
        		<td>2021-12-07</td>
        	</tr>
			<tr>
		<td>
			30		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=34&board_id=press&amp;page=1&amp;">[경상일보] ‘윈덤 강원 고성’, 모델하우스 오픈 본격 분양 나서</a>-->
			<a href="http://www.ksilbo.co.kr/news/articleView.html?idxno=920393" target="_blank">[경상일보] ‘윈덤 강원 고성’, 모델하우스 오픈 본격 분양 나서</a>
			            		</td>
        		<td>2021-12-06</td>
        	</tr>
			<tr>
		<td>
			29		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=33&board_id=press&amp;page=1&amp;">[AP신문] 글로벌 호텔그룹 윈덤, 고성서 '윈덤강원고성' 분양</a>-->
			<a href="http://apnews.kr/View.aspx?No=2135200" target="_blank">[AP신문] 글로벌 호텔그룹 윈덤, 고성서 '윈덤강원고성' 분양</a>
			            		</td>
        		<td>2021-12-03</td>
        	</tr>
			<tr>
		<td>
			28		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=32&board_id=press&amp;page=1&amp;">[한국목재신문] ‘윈덤 강원 고성’ 지난 1일 홍보관 오픈</a>-->
			<a href="http://www.woodkorea.co.kr/news/articleView.html?idxno=56013" target="_blank">[한국목재신문] ‘윈덤 강원 고성’ 지난 1일 홍보관 오픈</a>
			            		</td>
        		<td>2021-12-02</td>
        	</tr>
			<tr>
		<td>
			27		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=31&board_id=press&amp;page=1&amp;">[경상일보] ‘윈덤 강원 고성’ 생활형숙박시설 12월1일 오늘 그랜드 오픈</a>-->
			<a href="http://www.ksilbo.co.kr/news/articleView.html?idxno=919961" target="_blank">[경상일보] ‘윈덤 강원 고성’ 생활형숙박시설 12월1일 오늘 그랜드 오픈</a>
			            		</td>
        		<td>2021-12-01</td>
        	</tr>
			<tr>
		<td>
			26		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=30&board_id=press&amp;page=1&amp;">[더드라이브] ‘윈덤 강원 고성’ 총 489실로 12월 1일 모델하우스 오픈 본격 분양</a>-->
			<a href="http://www.thedrive.co.kr/news/newsview.php?ncode=1065578190516968" target="_blank">[더드라이브] ‘윈덤 강원 고성’ 총 489실로 12월 1일 모델하우스 오픈 본격 분양</a>
			            		</td>
        		<td>2021-11-30</td>
        	</tr>
			<tr>
		<td>
			25		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=29&board_id=press&amp;page=1&amp;">[국토일보] 하이엔드 생활형숙박시설 ‘윈덤 강원 고성’ 12월 1일 그랜드 오픈</a>-->
			<a href="http://www.ikld.kr/news/articleView.html?idxno=244763" target="_blank">[국토일보] 하이엔드 생활형숙박시설 ‘윈덤 강원 고성’ 12월 1일 그랜드 오픈</a>
			            		</td>
        		<td>2021-11-29</td>
        	</tr>
			<tr>
		<td>
			24		</td>
				<td class="left1">
			&nbsp;
						&nbsp;
						            <!--<a href="?mode=view&amp;idx=28&board_id=press&amp;page=1&amp;">[경상일보] 하이엔드 생활형숙박시설 ‘윈덤 강원 고성’ 12월 1일 그랜드 오픈</a>-->
			<a href="http://www.ksilbo.co.kr/news/articleView.html?idxno=919299" target="_blank">[경상일보] 하이엔드 생활형숙박시설 ‘윈덤 강원 고성’ 12월 1일 그랜드 오픈</a>
			            		</td>
        		<td>2021-11-24</td>
        	</tr>
		</table>

<!-- 버튼 시작 -->
<div class="btnarea1 left mT20">
            <a href="?board_id=press"><span class="btnst3 dspm">목록</span></a>
                                                </div>
<!-- 버튼 끝 -->

<!-- 페이징 시작 -->
<div class="paging1 mT10">
<img src='/images/common/btn/btn_prev2.gif' align='middle' alt='첫페이지' title='첫페이지 버튼 비활성화' style='filter:alpha(opacity=50);' />&nbsp;<img src='/images/common/btn/btn_prev1.gif' align='middle' alt='이전페이지' title='이전페이지 버튼 비활성화' style='filter:alpha(opacity=50);' />&nbsp;&nbsp;<b>1</b>&nbsp;&nbsp;<a href='?board_id=press&page=2' class='a'>2</a>&nbsp;&nbsp;<a href='?board_id=press&page=3' class='a'>3</a>&nbsp;&nbsp;<a href='?board_id=press&page=2'><img src='/images/common/btn/btn_next1.gif' align='middle' alt='다음페이지' title='다음페이지' /></a>&nbsp;<a href='?board_id=press&page=3'><img src='/images/common/btn/btn_next2.gif' align='middle' alt='끝페이지' title='끝페이지' /></a></div>
<!-- 페이징 끝 -->


<!-- 검색 시작 -->
<div class="scharea1">
	<select id="search_type" class="select1">
		<option value="subject|contents">제목+내용</option>
		<option value="subject">제목</option>
		<option value="contents">내용</option>
		<option value="name">글쓴이</option>
	</select>
	<input type="text" id="search_word" class="input_type1" onkeypress="if(event.keyCode == '13') search_board('press');" value="" /><a href="javascript:search_board('press');"><span class="btnst7 dspm">검색</span></a>
</div>
<!-- 검색 끝 -->
<!-- 리스트 끝 -->                    
                </div>
            </div>
        </div>
    </div>
<div id="footer" class='sub1'>
	<div class="fcont">
    	<img src="/images/common/footer_logo1.png?v=1" alt="" class=""/>
       	<div class="copy1">
        	사업지 주소 : 강원도 고성군 토성면 봉포리 258-9 외 8필지  |  분양홍보관 : 서울특별시 강남구 자곡동 666  |  시행 : (주)리드온산업개발<br />
			COPYRIGHT 2021 (C) 윈덤 강원 고성. ALL RIGHTS RESERVED.
           <div class="partner mT30">
               <img src="/images/common/footer_partner1.png" alt="">
           </div>
            <p class="txt1 mT30">
            ※ 본 홈페이지에 사용된 CG 및 이미지, 문안 등은 소비자의 이해를 돕기 위해 제작된 것으로 실제와 차이가 있을 수 있으며, 건물의 색채 및 외부 상세 내역 등은 인·허가, 심의 및 법규의 변경 등으로 인하여 실제 시공시 변경될 수 있습니다.<br />
			※ 본 홈페이지의 제작 과정상 오탈자가 있을 수 있으므로 계약시 반드시 확인하시기 바랍니다.
            </p>
        </div>
    	<div class="coop">         	
        	<img src="/images/common/footer_tel1.png" alt="" class="" />
        </div>  
    </div>
</div>
<iframe name="dfile" width="0" height="0" style="display:none;" title="빈프레임"></iframe>
<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>
<script type="text/javascript">
if(!wcs_add) var wcs_add = {};
wcs_add["wa"] = "ffaa54ca6bab30";
if(window.wcs) {
  wcs_do();
}
</script></body>
</html>	   