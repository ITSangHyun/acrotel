<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ko" xml:lang="ko">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=EDGE" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="keywords" content=""/>
<meta name="description" content="관심고객등록">
<meta property="og:type" content="website">
<meta property="og:title" content="REGISTER - REGISTER - 윈덤 강원 고성">
<meta property="og:description" content="관심고객등록">
<meta property="og:image" content="http://wyndham-gwgs.co.kr/images/common/ogimage.gif">
<meta property="og:url" content="http://wyndham-gwgs.co.kr">

<!--<link rel="stylesheet" type="text/css" href="/common/css/common.css?v=20211231071955"/>-->
<link rel="stylesheet" type="text/css" href="/common/css/font.css"/>
<link rel="stylesheet" type="text/css" href="/common/css/base.css?v=20211231071955"/>
<link rel="stylesheet" type="text/css" href="/common/css/layout.css?v=20211231071955"/>
<link rel="stylesheet" type="text/css" href="/common/css/content.css?v=20211231071955"/>
<link rel="stylesheet" type="text/css" href="/common/css/board.css?v=20211231071955"/>
<script type="text/javascript" src="/common/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/common/js/common.js?v=20211231071955"></script>
<script type="text/javascript" src="/common/js/script_top.js?v=1"></script>
<meta name="naver-site-verification" content="28291699597803fe9e8d8edf40ea1bf286da22dd" /><title>REGISTER - REGISTER - 윈덤 강원 고성</title>
<script type="text/javascript">
$(document).ready(function (){
	
});	
</script>
</head>
	<body>
	<div id="spNavi">
	<h3>메뉴바로가기</h3>
    <a href="#content">본문 내용으로 바로가기</a> 
    <a href="#left">메뉴으로 바로가기</a> 
	</div>

		
	<div id="header">
    	
    	<div id="menu-Area" class='sub'>
        	<div class="gnbbox1">
            			</div>
        	<div id="menu-box">
            	<div class="bgdepth1">                
                    <a href="/"><img src="/images/common/logo1.png" alt="" class="logo1 chg1" /></a>
                        
                    <div class="mmnbtn1">
                        <div class="btn trigger"><span class="line"></span></div>
                    </div>
                    <div class="topmenu">                                        	                        
                        <ul class="menudep1">  
                        	<li class="mmenu0"><a href="/" class="mnlnk1">HOME</a></li>
                                                        <li class="mmenu0"><a href="/wyndham/wyndham.php" class="mnlnk1 ">WYNDHAM</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/wyndham/wyndham.php">WYNDHAM</a></li> 
                                                                	<li><a href="/wyndham/brand.php">BRAND</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/info/overview.php" class="mnlnk1 ">SUMMARY</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/info/overview.php">OVERVIEW</a></li> 
                                                                	<li><a href="/direction/direction.php">DIRECTIONS</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/premium/premium.php" class="mnlnk1 ">PREMIUM</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/premium/premium.php">PREMIUM</a></li> 
                                                                	<li><a href="/location/location.php">LOCATION</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/unit/plan.php" class="mnlnk1 ">UNIT</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/unit/plan.php">PLAN</a></li> 
                                                                	<li><a href="/unit/special.php">SPECIAL</a></li> 
                                                                	<li><a href="/unit/community.php">COMMUNITY</a></li> 
                                                                	<li><a href="/unit/type.php">TYPE</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/register/client.php" class="mnlnk1 on ">REGISTER</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/register/client.php">REGISTER</a></li> 
                                                                	<li><a href="/reserve/visit.php" onclick="return _alert('준비중입니다.');">RESERVATION</a></li> 
                                                                	<li><a href="/register/media.php">MEDIA</a></li> 
                                                                	<li><a href="/register/news.php">NEWS</a></li> 
                                                                </ul>
                                                            </li>    
                                                 
                        </ul>                                                                     
                    </div>       
                    <div class="mnbnn1">
                        <img src="/images/common/top_tel1.png" alt="" class="chg1" />
                        <a href="/register/client.php" class="mL20"><img src="/images/common/btn_client1.png" alt="" /></a>
                    </div>             
                </div>                
			</div>                                               
        </div>   
    </div>
    
    <div class="svisualbox1">            	
    <div class="slider1">
         <!-- Jssor Slider Begin -->
        <!-- You can move inline styles to css file or css block. --> 
        <div id="slider1_container" class="slider_sub1">
            
            <!-- Loading Screen --> 
            <div u="loading" style="position: absolute; top: 0px; left: 0px;">
                <div style="filter: alpha(opacity=20); opacity:0.2; position: absolute; display: block; background-color: #e4e4e4; top: 0px; left: 0px;width: 100%; height:100%;"> </div> 
                <div style="position: absolute; display: block; background: url(/images/common/ico/ajax-loader.gif) no-repeat center center; top: 0px; left: 0px;width: 100%;height:100%;"> </div> 
            </div> 
            
            <!-- Slides Container --> 
            <div u="slides" class="slider_box1">                        	                        	                            
                <div>
                    <!--<img u="image" src="/images/sub/visual1_211019.jpg" />-->
					<img u="image" src="/images/sub/visual1_211026.jpg?v=1" />
                    <div u="caption" style="position: absolute; left:0; top:316px; width:100%; height:200px; text-align:center;">
                    	<div class="subtitbox1">                        	
                            <h2>관심고객등록</h2>
                            <em class="tit1">REGISTER</em>
                                                        <p>윈덤의 오너(Owner)에게</br>최고의 아너(Honour)를</p>
                            						</div>
					</div>
                </div>                  	
            </div> 
            
            <!-- Bullet Navigator Skin Begin -->
            <!-- bullet navigator container -->
            <div u="navigator" class="jssorb03" style="position: absolute; bottom: 16px; left: 6px;">
            <!-- bullet navigator item prototype -->
                <div u="prototype" style="POSITION: absolute; WIDTH: 21px; HEIGHT: 21px; text-align:center; line-height:21px; color:White; font-size:12px;"><div u="numbertemplate"></div></div>
            </div>
            <!-- Bullet Navigator Skin End -->
            
            <!-- Arrow Navigator Skin Begin -->
            <!-- Arrow Left -->
            <span u="arrowleft" class="jssora20l"></span>
            <!-- Arrow Right -->
            <span u="arrowright" class="jssora20r"></span>
            <!-- Arrow Navigator Skin End -->
        </div> 
        <!-- Jssor Slider End -->
    </div>
</div>
<script type="text/javascript" src="/common/js/SplitText.js"></script>
<script type="text/javascript" src="/common/js/TweenMax.min.js"></script>
<script type="text/javascript">
$(document).ready(function(e) {
 	$ele = $(".svisualbox1");
	//$bg = $ele.find(".slider1");
	$title1 = $ele.find(".tit1");   
	$title2 = $ele.find("h2"); 
	$title3 = $ele.find("p");
	$menu = $ele.find(".submn1>li"); 
	
	var mySplitText = new SplitText($title2, { type: "chars"});
	//var word_tl = new TimelineLite({delay:1});
	var shuffleCharArray = shuffleArray(mySplitText.chars);           
	       

	TweenLite.set(shuffleCharArray, {autoAlpha:0}); 

	tl = new TimelineLite({paused:true, onComplete:function(){  }});           	
	tl.staggerTo(shuffleCharArray, .8, {autoAlpha: 1, ease:Cubic.easeOut}, 0.01)   
	tl.staggerFrom($menu,.4, {autoAlpha: 0, y:20, ease:Cubic.easeOut}, 0.04)	
	//tl.from($bg, 2, {autoAlpha:0, scale:1.12, skewX:0.001, ease:Power2.easeOut}, "-=2.9")             
	tl.from($title1, .7, {autoAlpha:0, y:-20, ease:Power2.easeOut}, "-=.8")
	tl.from($title3, .7, {autoAlpha:0, y:-20, ease:Power2.easeOut}, "-=.8")
	//tl.to($ele, 1.2, {height:740, ease:Power2.easeOut}, "-=1.2")
	tl.play();
	//tl.timeScale(1.5);

	function shuffleArray(array) {
		for (var i = array.length - 1; i > 0; i--) {
			var j = Math.floor(Math.random() * (i + 1));
			var temp = array[i];
			array[i] = array[j];
			array[j] = temp;
		}
		return array;
	}
});
</script>

<link rel="stylesheet" type="text/css" href="/common/css/jssor/jssor.css"/>
<script type="text/javascript" src="/common/js/jssor/jssor.js"></script>
<script type="text/javascript" src="/common/js/jssor/jssor.slider.js"></script>
<script type="text/javascript" src="/common/js/jssor/scripts2.js"></script>	    <div id="wrap">
        <div id="swrap">   
            <div id="scontent">
                <div id="content">
                    <style type="text/css">
	.clbox1{position:absolute; right:50%; top:100px; margin-right:-640px; width:1280px; height:651px; z-index:10001;background:url(extra/img/bg_pop1.gif) no-repeat;; }
	.clbox1 div, .clbox1 table{margin:0 auto;}
	.clbox1 .popcont{width:980px; height:480px; margin:0 auto; margin-top:140px;}
	.clbox1 img.tit{position:absolute; left:150px; top:45px;}
	.clbox1 img.close{position:absolute; right:20px; top:66px;}
	.clbox1 .btnbox02{margin-top:10px}		
	.clbox1 p{width:640px; margin:0 auto;}
	.tbl01 {border-top:2px solid #2392a4;}
</style>


<script type="text/javascript" src="/common/js/formutil.js"></script>
<script src="http://dmaps.daum.net/map_js_init/postcode.v2.js"></script><script type="text/javascript">
	$(window).ready(function (){
		for(var i=1; i<7; i++){$("#none0"+i).css("display","none");}
				$(".lnktab02").click();
			});	
	
	/*체크확인*/
	function checkedTF(obj, cnt){
	var i = 0;
	var chk = 0;
	var val = "";
	for(i=0; i<obj.length; i++){if(obj[i].checked == true){chk += 1; val += obj[i].value;}}
	if(chk == 0) return false;
	else{
		if (cnt != null){
			if (chk < cnt) return false;
			else return true;
			}
		else{
			if(val == "") return false;
			else return true;
			}
		}
	}
		
	function tabOn(val){
		$(".lnktab01").attr("class","lnktab01");
		$(".lnktab02").attr("class","lnktab02");	
		if(val == 1){
			$("#chktxt01").attr("class","tit");	
			$("#chktxt02").attr("class","tit");	
			$("#chktxt01 > label").text("이름");		
			$("#chktxt02 > input").attr("title","이름 입력란");
			$(".tbl01").attr("summary","이름, 연락처, 휴대전화, 주소, 이메일 순으로 입력하는 관심고객 개인 등록 표입니다.");
			$(".tbl01 > caption").text("관심고객 개인 등록 표");
			for(var i=1; i<7; i++){$("#none0"+i).css("display","none");}
		}
		else{
			$("#chktxt01").attr("class","");
			$("#chktxt02").attr("class","");	
			$("#chktxt01 > label").text("대표자명");
			$("#chktxt02 > input").attr("title","대표자명 입력란");
			$(".tbl01").attr("summary","이용자ID, 비밀번호, 비밀번호확인, 사업자번호, 업체명, 대표자명, 연락처, 휴대전화, 주소, 이메일 순으로 입력하는 관심고객 공인중개사 등록 표입니다.");
			$(".tbl01 > caption").text("관심고객 공인중개사 등록 표");			
			for(var i=1; i<7; i++){$("#none0"+i).css("display","block");}
		}
		$(".lnktab0"+val).attr("class","lnktab0"+val+" on");
		$("#chk_m").val(val);
		}
	function _onSubmit(){
		var form = document.form;
		
		if($('input:radio[name="i_agree"]:checked').length == 0 || $('input:radio[name="i_agree"]:checked').val() != 'Y'){
		alert("개인정보수집 및 이용동의란에 동의 해주세요.");
		return false;
		}
		
		if($('input:radio[name="i_sms_cd"]:checked').length == 0 ){
		alert("마케팅 정보활용 이용동의를 확인 해주세요.");
		return false;
		}
		
		if(form.chk_m.value == 2){
			
			if(form.i_id.value == ""){
				alert('이용자ID를 입력하세요');
				form.i_id.focus();
				return false;
			}	
			
			if(!checkID_DT(form.i_id, 4, 16)){
				return false;
				}
				
			if(form.i_pwd01.value == ""){
				alert('비밀번호를 입력하세요');
				form.i_pwd01.focus();
				return false;
			}			
			
			if(!checkPassword(form.i_pwd01, '')){
				return false;
				}
			
			if(form.i_pwd02.value == ""){
				alert('비밀번호 확인을 입력하세요');
				form.i_pwd02.focus();
				return false;
			}
			if(form.i_corpno01.value == ""){
				alert('사업자번호를 입력하세요');
				form.i_corpno01.focus();
				return false;
			}
			if(form.i_corpno02.value == ""){
				alert('사업자번호를 입력하세요');
				form.i_corpno02.focus();
				return false;
			}	
			if(form.i_corpno03.value == ""){
				alert('사업자번호를 입력하세요');
				form.i_corpno03.focus();
				return false;
			}
					
			if(!check_corpno(form.i_corpno01.value+form.i_corpno02.value+form.i_corpno03.value)){
				alert("사업자 번호가 올바르지 않습니다.");
				return false;
				}
			
			if(form.i_corpname.value == ""){
				alert('업체명을 입력하세요');
				form.i_corpname.focus();
				return false;
			}	
			if(form.i_tel01.value != ""){
				if(!checkPhone(form.i_tel01)){
				return false;
				}
			}
			if(form.i_tel02.value != ""){
				if(!checkPhone(form.i_tel02)){
				return false;
				}
			}
			if(form.i_tel03.value != ""){
				if(!checkPhone(form.i_tel03)){
				return false;
				}
			}	
			if(form.i_name.value == ""){
				alert('대표자명을 입력하세요');
				form.i_name.focus();
				return false;
			}		
		}
		else{
			if(form.i_name.value == ""){
				alert('이름을 입력 해주세요');
				form.i_name.focus();
				return false;
			}
		}
		/*
		if(form.i_age.value == ""){
			alert('나이를 입력하세요');
			form.i_age.focus();
			return false;
		}
		
		if(!checkedTF(form.i_age)){
			alert('나이를 선택해주세요.');
			return false;
		}
		if(!checkedTF(form.i_hope)){
			alert('관심타입을 선택해주세요.');
			return false;
		}
		*/
		if(form.i_tel01.value == ""){
			alert('전화번호를 입력하세요');
			form.i_tel01.focus();
			return false;
		}
		if(form.i_tel02.value == ""){
			alert('전화번호를 입력하세요');
			form.i_tel02.focus();
			return false;
		}
		if(form.i_tel03.value == ""){
			alert('전화번호를 입력하세요');
			form.i_tel03.focus();
			return false;
		}
		
	/*
		
		if(form.i_zipcode01.value == ""){
			alert('주소를 입력하세요');
			return false;
		}
		
		if(form.i_addr01.value == ""){
			alert('주소를 입력하세요');
			return false;
		}
		
		*/
		if(!checkPhone(form.i_tel01)){
		return false;
		}
		if(!checkPhone(form.i_tel02)){
		return false;
		}
		if(!checkPhone(form.i_tel03)){
		return false;
		}
		
		return true;
	}
	function openAddr() {
	var form = document.form;
				new daum.Postcode({
            oncomplete: function(data) {
                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

                // 도로명 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var fullRoadAddr = data.roadAddress; // 도로명 주소 변수
                var extraRoadAddr = ''; // 도로명 조합형 주소 변수

                // 법정동명이 있을 경우 추가한다. (법정리는 제외)
                // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
                if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                    extraRoadAddr += data.bname;
                }
                // 건물명이 있고, 공동주택일 경우 추가한다.
                if(data.buildingName !== '' && data.apartment === 'Y'){
                   extraRoadAddr += (extraRoadAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                }
                // 도로명, 지번 조합형 주소가 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
                if(extraRoadAddr !== ''){
                    extraRoadAddr = ' (' + extraRoadAddr + ')';
                }
                // 도로명, 지번 주소의 유무에 따라 해당 조합형 주소를 추가한다.
                if(fullRoadAddr !== ''){
                    fullRoadAddr += extraRoadAddr;
                }

                // 우편번호와 주소 정보를 해당 필드에 넣는다.
				
				//form.i_zipcode01.value = data.postcode;
                form.i_zipcode01.value = data.zonecode;//5자리 기초구역번호 사용
               	form.i_addr01.value = fullRoadAddr;
                form.i_addr02.focus();
                //document.getElementById("sample4_jibunAddress").value = data.jibunAddress;

                // 사용자가 '선택 안함'을 클릭한 경우, 예상 주소라는 표시를 해준다.
				/*
                if(data.autoRoadAddress) {
                    //예상되는 도로명 주소에 조합형 주소를 추가한다.
                    var expRoadAddr = data.autoRoadAddress + extraRoadAddr;
                    document.getElementById("guide").innerHTML = '(예상 도로명 주소 : ' + expRoadAddr + ')';

                } else if(data.autoJibunAddress) {
                    var expJibunAddr = data.autoJibunAddress;
                    document.getElementById("guide").innerHTML = '(예상 지번 주소 : ' + expJibunAddr + ')';

                } else {
                    document.getElementById("guide").innerHTML = '';
                }*/
            }
        }).open();
		    }
	</script>

	
    <!--div class="tab01">
    	<ul>
        <li><a href="#" class="lnktab01<%=iif(chk_m<>2, " on", "")%>" onclick="tabOn(1); return false;">개인</a></li>
                <li><a href="#" class="lnktab02" onclick="tabOn(2); return false;">공인중개사</a></li>
                </ul>
    </div-->
    <form name="form" id="form" method="post" target="dfile" action="http://wyndham-gwgs.co.kr/extra/join_proc.php" onsubmit="return _onSubmit();">
    <fieldset>
    <legend>관심고객, 공인중개사 등록폼</legend>
    <input type="hidden" name="chk_m" id="chk_m" value="1" />
    <input type="hidden" name="i_site_cd" value="ho" />
    <input type="hidden" name="pageNum" value="" />    
    <table width="100%" class="tbl1 t2 " cellpadding="0" cellspacing="0" summary="이름, 주소, 휴대전화, 이메일 순으로 입력하는 관심고객 개인 등록 표입니다.">
    <caption>관심고객 개인 등록 표</caption>
    <colgroup>
        <col width="16%" />
    <col width="" />
        </colgroup>
    <tr id="none01">
    <th class="tit"><label for="i_id">이용자 ID</label></th>
   	<td class="tit"><input type="text" name="i_id" id="i_id" class="input_type1" style="width:140px;" maxlength="20" title="ID 입력란" /> <a href="#" onclick="chk_Id(); return false;">중복</a></td>
    </tr>
    <tr id="none02">
    <th><label for="i_pwd01">비밀번호</label></th>
   	<td><input type="password" name="i_pwd01" id="i_pwd01" class="input_type1" style="width:140px;" maxlength="20" title="비밀번호 입력란" /></td>
    </tr>
    <tr id="none03">
    <th><label for="i_pwd02">비밀번호확인</label></th>
   	<td><input type="password" name="i_pwd02" id="i_pwd02" class="input_type1" style="width:140px;" maxlength="20" title="비밀번호 확인 입력란" /></td>
    </tr>
    <tr id="none04">
    <th><label for="i_corpno01">사업자번호</label></th>
   	<td>
    <input type="text" name="i_corpno01" id="i_corpno01" class="input_type1" style="width:30px;" maxlength="3" onkeyup="isNumchk(this)" title="사업자 앞번호 입력란" /> -
    <input type="text" name="i_corpno02" id="i_corpno02" class="input_type1" style="width:20px;" maxlength="2" onkeyup="isNumchk(this)" title="사업자 가운데번호 입력란" /> -
    <input type="text" name="i_corpno03" id="i_corpno03" class="input_type1" style="width:40px;" maxlength="5" onkeyup="isNumchk(this)" title="사업자 뒷번호 입력란" />
    </td>
    </tr>
    <tr id="none05">
    <th><label for="i_corpname">업체명</label></th>
   	<td><input type="text" name="i_corpname" id="i_corpname" class="input_type1" style="width:140px;" maxlength="20" title="업체명 입력란" /></td>
    </tr>
    <tr>
    <th id="chktxt01" class="tit"><label for="i_name">이름</label></th>
   	<td id="chktxt02" class="tit left1"><input type="text" name="i_name" id="i_name" class="input_type1" style="width:140px;" maxlength="20" title="이름 입력란" /> </td>
    </tr>
    <tr>
    <th><label for="i_tel01">전화번호</label></th>
   	<td class="left1">
    <input type="text" name="i_tel01" id="i_tel01" class="input_type1" style="width:40px;" maxlength="4" onkeyup="isNumchk(this)" title="연락처 앞번호 입력란" /> -
    <input type="text" name="i_tel02" id="i_tel02" class="input_type1" style="width:40px;" maxlength="4" onkeyup="isNumchk(this)" title="연락처 가운데번호 입력란" /> -
    <input type="text" name="i_tel03" id="i_tel03" class="input_type1" style="width:40px;" maxlength="4" onkeyup="isNumchk(this)" title="연락처 뒷번호 입력란" />
    </td>
    </tr>
    <!--
    <tr>
    <th><label for="i_age1">연령</label></th>
    <td colspan="3">
    <label for="i_age1"><input type="radio" name="i_age" id="i_age1" value="20대" />20대</label>
    <label for="i_age2"><input type="radio" name="i_age" id="i_age2" value="30대" />30대</label>
    <label for="i_age3"><input type="radio" name="i_age" id="i_age3" value="40대" />40대</label>
    <label for="i_age4"><input type="radio" name="i_age" id="i_age4" value="50대" />50대</label>
    <label for="i_age5"><input type="radio" name="i_age" id="i_age5" value="60대이상" />60대이상</label>
    </td>
    </tr>
    <tr>
    <th><label for="i_hope1">관심타입</label></th>
    <td colspan="3">
    <label for="i_hope1"><input type="radio" name="i_hope" id="i_hope1" value="72㎡A" />72㎡A</label>
    <label for="i_hope2"><input type="radio" name="i_hope" id="i_hope2" value="72㎡B" />72㎡B</label>
    <label for="i_hope3"><input type="radio" name="i_hope" id="i_hope3" value="84㎡A" />84㎡A</label>
    <label for="i_hope4"><input type="radio" name="i_hope" id="i_hope4" value="84㎡B" />84㎡B</label>
    </td>
    </tr>
    -->
    <tr>
    <th><label for="i_email01">이메일</label></th>
   	<td class="left1">
    <input type="text" id="i_email01" name="i_email01" class="input_type1" maxlength="50" onkeyup="fnLowerCase(this)" title="이메일 입력란" style="width:20%;" /> @
    <input type="text" id="i_email02" name="i_email02" class="input_type1" maxlength="35" onkeyup="fnLowerCase(this)" title="이메일 도메인 입력란" style="width:18%;" />
    <select id="email_domain" name="email_domain"
    onchange="domain_chk(this, this.form.i_email02);" title="도메인선택" class="input_type1">
    <option value="">직접 입력</option>
    <option value="nate.com">nate.com</option>
    <option value="empas.com">empas.com</option>
    <option value="lycos.co.kr">lycos.co.kr</option>
    <option value="netsgo.com">netsgo.com</option>
    <option value="chol.com">chol.com</option>
    <option value="dreamwiz.com">dreamwiz.com</option>
    <option value="gmail.com">gmail.com</option>
    <option value="hanmail.net">hanmail.net</option>
    <option value="daum.net">daum.net</option>
    <option value="hotmail.com">hotmail.com</option>
    <option value="korea.com">korea.com</option>
    <option value="naver.com">naver.com</option>
    <option value="netian.com">netian.com</option>
    <option value="yahoo.co.kr">yahoo.co.kr</option>
    <option value="yahoo.com">yahoo.com</option>
    </select>
    </td>
    </tr>
    <tr>
    <th><label for="i_addr02">주소</label></th>
    <td class="left1">
    <input type="text" name="i_zipcode01" id="i_zipcode01" class="input_type1" style="width:20%; max-width:80px;" title="우편번호 앞자리 입력란" readonly="readonly" />
    <a href="#" onclick="openAddr();return false;" target="_blank" title="우편번호 검색 새창으로 이동"><span class="btnst10 dspm">우편번호검색</span></a>
    <br />
    <input type="text" name="i_addr01" id="i_addr01" class="input_type1 mT4" style="width:80%; max-width:240px;" title="주소 입력란" readonly="readonly" />
                <input type="text" name="i_addr02" id="i_addr02" class="input_type1 mT4" style="width:60%; max-width:200px;" title="주소 입력란" /></td>
    </tr>
    <tr id="none06">
    <th><label for="i_mb01">휴대전화</label></th>
   	<td class="left1">
    <input type="text" name="i_mb01" id="i_mb01" class="input_type1" style="width:30px;" maxlength="4" onkeyup="isNumchk(this)" title="휴대전화 앞번호 입력란" /> -
    <input type="text" name="i_mb02" id="i_mb02" class="input_type1" style="width:30px;" maxlength="4" onkeyup="isNumchk(this)" title="휴대전화 가운데번호 입력란" /> -
    <input type="text" name="i_mb03" id="i_mb03" class="input_type1" style="width:30px;" maxlength="4" onkeyup="isNumchk(this)" title="휴대전화 뒷번호 입력란" />
    </td>
    </tr>    
    <!--tr>
    <th><label for="i_hope1">관심이유</label></th>
    <td>
    <label for="i_hope1"><input type="radio" name="i_hope" id="i_hope1" title="관심이유 선택" value="실수요" checked="checked" />실수요</label>&nbsp;&nbsp;
    <label for="i_hope2"><input type="radio" name="i_hope" id="i_hope2" title="관심이유 선택" value="투자" />투자</label>&nbsp;&nbsp;
    <label for="i_hope3"><input type="radio" name="i_hope" id="i_hope3" title="관심이유 선택" value="기타" />기타</label>&nbsp;&nbsp;
     </td>
    </tr-->
    </table>  
    
    
    <div class="stitbox1 left mT40">
        <em class="tit1">[필수] 개인정보 수집 / 이용 동의</em>
        <p>
          	‘윈덤 강원 고성’는 고객님께 분양 정보 제공에 필요한 최소한의 개인정보를 수집하고 있습니다.<br />
이에 개인정보의 수집 및 이용에 관하여 아래와 같이 안내하오니 충분히 읽어 보신 후 동의하여 주시기 바랍니다.
        </p>
    </div>
    
    <table width="100%" class="tbl1 mT20" cellpadding="0" cellspacing="0">
    <colgroup>
        <col width="26%" />
    <col width="" />
        </colgroup>
    <tr>
    <th>개인정보의 수집주체</th>
    <td class="tit1"><strong>시행</strong> : (주)리드온산업개발</td>
    </tr>
    <tr>
    <th>개인정보 취급위탁</th>
    <td>상기 기재한 개인정보는 (주)리드온산업개발에 위탁되어 DM발송, 판촉 및 문자 서비스에 사용됩니다.</td>
    </tr>
    <tr>
    <th>개인정보의 수집/이용 항목</th>
    <td>이름, 주소, 연락처, 이메일</td>
    </tr>
    <tr>
    <th>개인정보의 수집/이용 목적</th>
    <td>『윈덤 강원 고성』 의 주요 문의사항 파악, 고객상담이력관리, 당사 분양상품에 대한 안내(전화, 문자, 우편)</td>
    </tr>
    <tr>
    <th>개인정보의 보유 및 이용기간</th>
    <td>분양완료 후 30일 이내 (이후 폐기합니다. 본 동의 철회 시 즉시 폐기됩니다.)</td>
    </tr>
    <tr>
    <th>개인정보 동의를 거부할 권리</th>
    <td>귀하께서는 개인정보 수집/이용을 거절할 수 있으며, 거절하실 경우 분양정보 안내 등의 서비스를 제공해 드릴 수 없습니다.</td>
    </tr>
    </table>
    
    <p class="stxtbox1 left mT10">
    <span>※ 위와 같이 개인정보를 수집/이용하는데 동의하십니까?</span>&emsp;
    <label for="i_agree"><input type="radio" name="i_agree" id="i_agree" title="개인정보를 수집/이용 선택란" value="Y" />동의함</label>&emsp; <label for="i_agree2"><input type="radio" name="i_agree" id="i_agree2" title="개인정보를 수집/이용 선택란" value="N" />동의하지 않음.</label>
    </p>
    <div class="cboth"></div>
    <div class="stitbox1 left mT50">
    	<em class="tit1">[선택] 마케팅 정보 활용 동의</em>
    </div>
    
    <table width="100%" class="tbl1 mT20" cellpadding="0" cellspacing="0">
    <colgroup>
        <col width="26%" />
    <col width="" />
        </colgroup>
    <tr>
    <th>마케팅 정보 활용의 수집주체</th>
    <td class="tit1"><strong>시행</strong> : (주)리드온산업개발</td>
    </tr>
    <tr>
    <th>마케팅 정보 활용 이용항목</th>
    <td>이름, 주소, 연락처, 이메일</td>
    </tr>
    <tr>
    <th>마케팅 정보 활용 이용목적</th>
    <td>마케팅 정보제공에 동의시 새로운 정보를 제공받으실 수 있으며, 각종 이벤트에도 참여할 수 있습니다.<br />본 정보는 고객님이 동의한 활용 목적으로만 사용하고 있습니다.
    </td>
    </tr>
    <tr>
    <th>마케팅 정보 활용 이용기간</th>
    <td>마케팅 정보 활용 동의 시점부터 1년간 (이후 폐기합니다. 본 동의 철회시 즉시 폐기됩니다.)</td>
    </tr>
    <tr>
    <th>마케팅 정보 활용 동의를 거부할 권리</th>
    <td><strong>귀하께서는 마케팅 정보 활용 동의를 거절할 수 있으며, 거절하실 경우 분양정보 안내 등의 서비스를 제공해 드릴 수 없습니다.</strong></td>
    </tr>
    </table>
    
    <p class="stxtbox1 left mT10">
    <span>※ 위와 같이 마케팅 정보활용에 동의하십니까?(선택)</span>&emsp;
    <label for="i_sms_cd1"><input type="radio" name="i_sms_cd" id="i_sms_cd1" title="마케팅 정보활용 선택란" value="Y" />동의함</label>&emsp; <label for="i_sms_cd2"><input type="radio" name="i_sms_cd" id="i_sms_cd2" title="마케팅 정보활용 선택란" value="N" />동의하지 않음.</label>
    </p>
    
	
    
    
    <div class="btnarea1 mT20">
        <input type="submit"class="btnst1" value="등록" />
        <a href="#" onclick="document.form.reset(); return false;"><input type="button" class="btnst5" value="취소" /></a>
    </div>
    </fieldset>
    </form>
    
                        
                </div>
            </div>
        </div>
    </div>
<div id="footer" class='sub1'>
	<div class="fcont">
    	<img src="/images/common/footer_logo1.png?v=1" alt="" class=""/>
       	<div class="copy1">
        	사업지 주소 : 강원도 고성군 토성면 봉포리 258-9 외 8필지  |  분양홍보관 : 서울특별시 강남구 자곡동 666  |  시행 : (주)리드온산업개발<br />
			COPYRIGHT 2021 (C) 윈덤 강원 고성. ALL RIGHTS RESERVED.
           <div class="partner mT30">
               <img src="/images/common/footer_partner1.png" alt="">
           </div>
            <p class="txt1 mT30">
            ※ 본 홈페이지에 사용된 CG 및 이미지, 문안 등은 소비자의 이해를 돕기 위해 제작된 것으로 실제와 차이가 있을 수 있으며, 건물의 색채 및 외부 상세 내역 등은 인·허가, 심의 및 법규의 변경 등으로 인하여 실제 시공시 변경될 수 있습니다.<br />
			※ 본 홈페이지의 제작 과정상 오탈자가 있을 수 있으므로 계약시 반드시 확인하시기 바랍니다.
            </p>
        </div>
    	<div class="coop">         	
        	<img src="/images/common/footer_tel1.png" alt="" class="" />
        </div>  
    </div>
</div>
<iframe name="dfile" width="0" height="0" style="display:none;" title="빈프레임"></iframe>
<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>
<script type="text/javascript">
if(!wcs_add) var wcs_add = {};
wcs_add["wa"] = "ffaa54ca6bab30";
if(window.wcs) {
  wcs_do();
}
</script></body>
</html>	   