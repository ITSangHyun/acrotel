<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ko" xml:lang="ko">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=EDGE" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="keywords" content=""/>
<meta name="description" content="방문예약">
<meta property="og:type" content="website">
<meta property="og:title" content="RESERVATION - REGISTER - 윈덤 강원 고성">
<meta property="og:description" content="방문예약">
<meta property="og:image" content="http://wyndham-gwgs.co.kr/images/common/ogimage.gif">
<meta property="og:url" content="http://wyndham-gwgs.co.kr">

<!--<link rel="stylesheet" type="text/css" href="/common/css/common.css?v=20211231071956"/>-->
<link rel="stylesheet" type="text/css" href="/common/css/font.css"/>
<link rel="stylesheet" type="text/css" href="/common/css/base.css?v=20211231071956"/>
<link rel="stylesheet" type="text/css" href="/common/css/layout.css?v=20211231071956"/>
<link rel="stylesheet" type="text/css" href="/common/css/content.css?v=20211231071956"/>
<link rel="stylesheet" type="text/css" href="/common/css/board.css?v=20211231071956"/>
<script type="text/javascript" src="/common/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/common/js/common.js?v=20211231071956"></script>
<script type="text/javascript" src="/common/js/script_top.js?v=1"></script>
<meta name="naver-site-verification" content="28291699597803fe9e8d8edf40ea1bf286da22dd" />
<title>RESERVATION - REGISTER - 윈덤 강원 고성</title>
</head>
	<body>
	<div id="spNavi">
	<h3>메뉴바로가기</h3>
    <a href="#content">본문 내용으로 바로가기</a> 
    <a href="#left">메뉴으로 바로가기</a> 
	</div>

		
	<div id="header">
    	
    	<div id="menu-Area" class='sub'>
        	<div class="gnbbox1">
            			</div>
        	<div id="menu-box">
            	<div class="bgdepth1">                
                    <a href="/"><img src="/images/common/logo1.png" alt="" class="logo1 chg1" /></a>
                        
                    <div class="mmnbtn1">
                        <div class="btn trigger"><span class="line"></span></div>
                    </div>
                    <div class="topmenu">                                        	                        
                        <ul class="menudep1">  
                        	<li class="mmenu0"><a href="/" class="mnlnk1">HOME</a></li>
                                                        <li class="mmenu0"><a href="/wyndham/wyndham.php" class="mnlnk1 ">WYNDHAM</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/wyndham/wyndham.php">WYNDHAM</a></li> 
                                                                	<li><a href="/wyndham/brand.php">BRAND</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/info/overview.php" class="mnlnk1 ">SUMMARY</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/info/overview.php">OVERVIEW</a></li> 
                                                                	<li><a href="/direction/direction.php">DIRECTIONS</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/premium/premium.php" class="mnlnk1 ">PREMIUM</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/premium/premium.php">PREMIUM</a></li> 
                                                                	<li><a href="/location/location.php">LOCATION</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/unit/plan.php" class="mnlnk1 ">UNIT</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/unit/plan.php">PLAN</a></li> 
                                                                	<li><a href="/unit/special.php">SPECIAL</a></li> 
                                                                	<li><a href="/unit/community.php">COMMUNITY</a></li> 
                                                                	<li><a href="/unit/type.php">TYPE</a></li> 
                                                                </ul>
                                                            </li>    
                                                        <li class="mmenu0"><a href="/register/client.php" class="mnlnk1 on ">REGISTER</a>
                            	                                
                            	<ul class="submn0">
                                                                	<li><a href="/register/client.php">REGISTER</a></li> 
                                                                	<li><a href="/reserve/visit.php" onclick="return _alert('준비중입니다.');">RESERVATION</a></li> 
                                                                	<li><a href="/register/media.php">MEDIA</a></li> 
                                                                	<li><a href="/register/news.php">NEWS</a></li> 
                                                                </ul>
                                                            </li>    
                                                 
                        </ul>                                                                     
                    </div>       
                    <div class="mnbnn1">
                        <img src="/images/common/top_tel1.png" alt="" class="chg1" />
                        <a href="/register/client.php" class="mL20"><img src="/images/common/btn_client1.png" alt="" /></a>
                    </div>             
                </div>                
			</div>                                               
        </div>   
    </div>
    
    <div class="svisualbox1">            	
    <div class="slider1">
         <!-- Jssor Slider Begin -->
        <!-- You can move inline styles to css file or css block. --> 
        <div id="slider1_container" class="slider_sub1">
            
            <!-- Loading Screen --> 
            <div u="loading" style="position: absolute; top: 0px; left: 0px;">
                <div style="filter: alpha(opacity=20); opacity:0.2; position: absolute; display: block; background-color: #e4e4e4; top: 0px; left: 0px;width: 100%; height:100%;"> </div> 
                <div style="position: absolute; display: block; background: url(/images/common/ico/ajax-loader.gif) no-repeat center center; top: 0px; left: 0px;width: 100%;height:100%;"> </div> 
            </div> 
            
            <!-- Slides Container --> 
            <div u="slides" class="slider_box1">                        	                        	                            
                <div>
                    <!--<img u="image" src="/images/sub/visual1_211019.jpg" />-->
					<img u="image" src="/images/sub/visual1_211026.jpg?v=1" />
                    <div u="caption" style="position: absolute; left:0; top:316px; width:100%; height:200px; text-align:center;">
                    	<div class="subtitbox1">                        	
                            <h2>방문예약</h2>
                            <em class="tit1">RESERVATION</em>
                            						</div>
					</div>
                </div>                  	
            </div> 
            
            <!-- Bullet Navigator Skin Begin -->
            <!-- bullet navigator container -->
            <div u="navigator" class="jssorb03" style="position: absolute; bottom: 16px; left: 6px;">
            <!-- bullet navigator item prototype -->
                <div u="prototype" style="POSITION: absolute; WIDTH: 21px; HEIGHT: 21px; text-align:center; line-height:21px; color:White; font-size:12px;"><div u="numbertemplate"></div></div>
            </div>
            <!-- Bullet Navigator Skin End -->
            
            <!-- Arrow Navigator Skin Begin -->
            <!-- Arrow Left -->
            <span u="arrowleft" class="jssora20l"></span>
            <!-- Arrow Right -->
            <span u="arrowright" class="jssora20r"></span>
            <!-- Arrow Navigator Skin End -->
        </div> 
        <!-- Jssor Slider End -->
    </div>
</div>
<script type="text/javascript" src="/common/js/SplitText.js"></script>
<script type="text/javascript" src="/common/js/TweenMax.min.js"></script>
<script type="text/javascript">
$(document).ready(function(e) {
 	$ele = $(".svisualbox1");
	//$bg = $ele.find(".slider1");
	$title1 = $ele.find(".tit1");   
	$title2 = $ele.find("h2"); 
	$title3 = $ele.find("p");
	$menu = $ele.find(".submn1>li"); 
	
	var mySplitText = new SplitText($title2, { type: "chars"});
	//var word_tl = new TimelineLite({delay:1});
	var shuffleCharArray = shuffleArray(mySplitText.chars);           
	       

	TweenLite.set(shuffleCharArray, {autoAlpha:0}); 

	tl = new TimelineLite({paused:true, onComplete:function(){  }});           	
	tl.staggerTo(shuffleCharArray, .8, {autoAlpha: 1, ease:Cubic.easeOut}, 0.01)   
	tl.staggerFrom($menu,.4, {autoAlpha: 0, y:20, ease:Cubic.easeOut}, 0.04)	
	//tl.from($bg, 2, {autoAlpha:0, scale:1.12, skewX:0.001, ease:Power2.easeOut}, "-=2.9")             
	tl.from($title1, .7, {autoAlpha:0, y:-20, ease:Power2.easeOut}, "-=.8")
	tl.from($title3, .7, {autoAlpha:0, y:-20, ease:Power2.easeOut}, "-=.8")
	//tl.to($ele, 1.2, {height:740, ease:Power2.easeOut}, "-=1.2")
	tl.play();
	//tl.timeScale(1.5);

	function shuffleArray(array) {
		for (var i = array.length - 1; i > 0; i--) {
			var j = Math.floor(Math.random() * (i + 1));
			var temp = array[i];
			array[i] = array[j];
			array[j] = temp;
		}
		return array;
	}
});
</script>

<link rel="stylesheet" type="text/css" href="/common/css/jssor/jssor.css"/>
<script type="text/javascript" src="/common/js/jssor/jssor.js"></script>
<script type="text/javascript" src="/common/js/jssor/jssor.slider.js"></script>
<script type="text/javascript" src="/common/js/jssor/scripts2.js"></script>	    <div id="wrap">
        <div id="swrap">   		
        	
            <div id="scontent">        	                
                <div id="content"  style="padding-top:80px;">
                   
                    
                    <script type="text/javascript" src="/common/js/formutil.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	_reCalendar();
	_onTab1($(".tab1 li a").eq(0));
});
function _reCalendar(mon,year){
	if (mon == undefined) mon = "";
	if (year == undefined) year = "";
	var form = document.form1;
	form.sidx.value = "";
	$("#timeBox").html('<p class="t1">날짜선택</p>');
	/*
	var url = "/reserve/proc/proc.php";
	$("#dateBox").load(url,{"pmode":"CAL","code":'00001',"mon":mon,"year":year}, function(responseTxt, statusTxt, xhr){
	});
	*/
	var url = "/reserve/proc/proc.php?pmode=CAL&code=00001&mon="+mon+"&year="+year;
	$("#dateBox").load(url, function(responseTxt, statusTxt, xhr){
	});
}

function _regsrve(){
	var form = document.form1;
	
	if($('input:radio[name="i_agree"]:checked').length == 0 || $('input:radio[name="i_agree"]:checked').val() != 'Y'){
		alert("개인정보수집 및 이용동의란에 동의 해주세요.");
		return false;
	}
	
	if(form.i_name.value == ""){
		alert('이름을 입력 해주세요');
		form.i_name.focus();
		return false;
	}
	if(form.i_tel01.value == ""){
		alert('연락처를 입력하세요');
		form.i_tel01.focus();
		return false;
	}
	if(!_phoneNumberChk(form.i_tel01.value)){
		alert("유효한 전화번호가 아닙니다. 확인부탁드립니다.");
		return false;
	}	
		
	if (form.sidx.value ==""){
		alert("방문하실 날짜,시간을 선택해주세요.");
		return false;
	}
	var chodate;
	chodate = $("#cho-date").find("em").text();
	chodate += " "+ $("#cho-time").find("em").text();
	
	//console.log(chodate);
	
	//if(confirm("선택하신 날짜("+chodate+")로 방문 신청하시겠습니까?")){	
		return true;
	//}
	//return false;
}

function _onTab1(obj){
	var index = $(obj).parent().index();
	$(obj).parents(".tab1").find("li").removeClass("on");
	$(obj).parents("li").addClass("on");
	$(".rtabcont").hide();
	$(".rtabcont").eq(index).show();
}	

function _chkForm(val){
	var form = document.chkform1;
		
	if(form.i_name.value == ""){
		alert('이름을 입력해주세요');
		form.i_name.focus();
		return false;
	}
	if(form.i_tel01.value == ""){
		alert('전화번호를 입력하세요');
		form.i_tel01.focus();
		return false;
	}
	if(!_phoneNumberChk(form.i_tel01.value)){
		alert("유효한 전화번호가 아닙니다. 확인부탁드립니다.");
		return false;
	}
		
	if (val == "CAN"){
		if(!confirm("예약 취소하시겠습니까?")){
			return false;
		}
	}
	
	divFilter($(document.body), "dobox1", "A", 320);
	var url="/reserve/proc/proc.php";  
	var name = form.i_name.value;
	var tel = form.i_tel01.value;	
		
	$("#dobox1").load(url,{"pmode":val,"i_name":name,"i_tel":tel,"code":"00001"}, function(responseTxt, statusTxt, xhr){
		//$(".resbox1").css({"top":Number($(window).scrollTop())+"px"})
		form.reset();
	});		
	return false;
}
function _closeWin(){
	$(".resbox1").remove();
	$("#dobox3").remove();		
}
</script>

<ul class="tab1">
    <li><a href="" onclick="_onTab1(this); return false;" class="f1">예약신청</a></li>
    <li><a href="" onclick="_onTab1(this); return false;" >예약확인 및 취소</a></li>
</ul>                    
<div class="cboth"></div>

<div class="rtabcont mT50">
    <div class="wscreenp1"><img src="/reserve/images/img_visit1.jpg" alt="" class="img1" /></div>
    <div class="wscreenm1"><img src="/reserve/images/img_visit1_m.jpg" alt="" class="img1" /></div>
    <div class="txtbox2 mT20">
        <em>예약신청</em>
        중복예약은 불가합니다
    </div>
    
    <div class="reservebox1">
        
        <form name="form1" id="form1" action="/reserve/proc/proc.php" method="post" target="dfile" onsubmit="return _regsrve();">
            <input type="hidden" name="pmode" value="REG" />
            <input type="hidden" name="code" value="00001" />
            <input type="hidden" name="idx" value="" />
            <input type="hidden" name="sidx" value="" />
                    예약 가능한 기간이 아닙니다.
                </form>
    </div>
    <div class="cboth"></div>
</div>

<div class="rtabcont mT50">
    <div class="center"></div>
    <div class="txtbox3 mT50">
        <em><strong>예약확인</strong> 및 <strong>취소</strong></em>
        본인의 이름과 연락처를 입력하시면<br />예약하셨던 날짜와 시간을 확인하실 수 있습니다.
    </div>
    <form name="chkform1" id="chkform1" action="" onsubmit="return _chkForm();">
    <div class="nbox1 mT50">
        <div class="cont1">    
            <div class="dbox1">
                <dl>
                    <dt><label for="i_name">이름</label></dt>
                    <dd>
                        <input type="text" name="i_name" id="i_name" class="input_type1" style="width:77%;" maxlength="20" title="이름 입력란" /> 
                    </dd>
                    <dt><label for="i_tel01">전화번호</label></dt>
                    <dd>
                        <input type="text" name="i_tel01" id="i_tel01" class="input_type1" maxlength="13" style="width:77%" onkeyup="_phoneNumber(this);" title="연락처 입력란" />
                                            </dd>
                </dl>
            </div>
            <div class="cboth"></div>
            <p class="center mT20">
                <a href="" onclick="return _chkForm('CHK');"><span class="btnst1 dsm dspm w1">예약확인 및 취소</span></a>
                <!--<a href="" onclick="return _chkForm('CAN');"><span class="btnst3 dsm dspm">예약취소</span></a>    -->
            </p>
        </div>
        <div class="cboth"></div>
    </div> 
    </form>
</div>                   
                    <div class="displayn1">
                    
                    </div>
                </div>
            </div>
        </div>
    </div> 
<div id="footer" class='sub1'>
	<div class="fcont">
    	<img src="/images/common/footer_logo1.png?v=1" alt="" class=""/>
       	<div class="copy1">
        	사업지 주소 : 강원도 고성군 토성면 봉포리 258-9 외 8필지  |  분양홍보관 : 서울특별시 강남구 자곡동 666  |  시행 : (주)리드온산업개발<br />
			COPYRIGHT 2021 (C) 윈덤 강원 고성. ALL RIGHTS RESERVED.
           <div class="partner mT30">
               <img src="/images/common/footer_partner1.png" alt="">
           </div>
            <p class="txt1 mT30">
            ※ 본 홈페이지에 사용된 CG 및 이미지, 문안 등은 소비자의 이해를 돕기 위해 제작된 것으로 실제와 차이가 있을 수 있으며, 건물의 색채 및 외부 상세 내역 등은 인·허가, 심의 및 법규의 변경 등으로 인하여 실제 시공시 변경될 수 있습니다.<br />
			※ 본 홈페이지의 제작 과정상 오탈자가 있을 수 있으므로 계약시 반드시 확인하시기 바랍니다.
            </p>
        </div>
    	<div class="coop">         	
        	<img src="/images/common/footer_tel1.png" alt="" class="" />
        </div>  
    </div>
</div>
<iframe name="dfile" width="0" height="0" style="display:none;" title="빈프레임"></iframe>
<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>
<script type="text/javascript">
if(!wcs_add) var wcs_add = {};
wcs_add["wa"] = "ffaa54ca6bab30";
if(window.wcs) {
  wcs_do();
}
</script></body>
</html>    