
	<script type='text/javascript'>
	<!--
		top.location.href='http://wyndham-gwgs.co.kr';
	//-->
	</script>
	